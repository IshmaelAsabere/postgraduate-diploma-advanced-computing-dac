import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentTable } from './Student/student.component';
import { StudentList } from './Student/studentlist.component';


const routes: Routes = [
{path:"table", component: StudentTable},
{path:"list", component: StudentList}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
