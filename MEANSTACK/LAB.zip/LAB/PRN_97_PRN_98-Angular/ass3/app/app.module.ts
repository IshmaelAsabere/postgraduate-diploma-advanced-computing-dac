import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { StudentService } from './Student/student.service';
import { StudentList } from './Student/studentlist.component';
import { StudentTable } from './Student/student.component';


@NgModule({
  declarations: [
    AppComponent, StudentList, StudentTable
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, HttpModule
  ],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
