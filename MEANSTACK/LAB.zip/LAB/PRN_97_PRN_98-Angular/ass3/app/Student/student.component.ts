import { Component } from '@angular/core';
import { template } from '@angular/core/src/render3';
import { StudentService } from './student.service';


@Component({
selector:'',
templateUrl:'./student.component.html',
styleUrls:['./student.component.css']
})


export class StudentTable{
 student=[{}];

constructor(private service:StudentService){};


ngOnInit(){
    this.service.getStudent().subscribe((p)=>this.student=p);
}

}