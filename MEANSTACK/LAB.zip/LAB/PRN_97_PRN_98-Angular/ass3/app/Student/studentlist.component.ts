import { Component } from '@angular/core';
import { template } from '@angular/core/src/render3';
import { StudentService } from './student.service';


@Component({
selector:'',
templateUrl:'./studentlist.component.html',
styleUrls:['./studentlist.component.css']
})


export class StudentList{
 student=[{}];

constructor(private service:StudentService){};


ngOnInit(){
    this.service.getStudent().subscribe((p)=>this.student=p);
}

}