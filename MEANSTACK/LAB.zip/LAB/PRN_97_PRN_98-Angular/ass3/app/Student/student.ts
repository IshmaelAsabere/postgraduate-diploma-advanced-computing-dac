export class Student{
    name;
    class;
    grade;
}