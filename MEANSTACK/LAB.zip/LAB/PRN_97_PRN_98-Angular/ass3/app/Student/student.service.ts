import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs';
import  'rxjs/add/operator/map';
import { Student } from './student';

@Injectable()
    export class StudentService{

        constructor(private http:Http){}
        
        getStudent():Observable<Student[]>
        {
            return this.http.get("assets/student.json").map((response:Response)=><Student[]>response.json());
        }
    }
