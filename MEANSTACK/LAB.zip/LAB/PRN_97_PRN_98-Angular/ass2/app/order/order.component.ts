import { Component } from '@angular/core';

@Component({

    selector:'oform',
    templateUrl:'./order.component.html',
    styleUrls:['./order.component.css']


})
export class Order{

   // arr=[];
    flag1=false;
   orders={oid:0,name:"",odate:"",mobnumber:0,itemno:0,itemname:"",qty:0};
    
submitForm(){
this.orders.oid=this.orders.oid;
this.orders.name=this.orders.name;
this.orders.odate=this.orders.odate;
this.orders.mobnumber=this.orders.mobnumber;
this.orders.itemno=this.orders.itemno;
this.orders.itemname=this.orders.itemname;
this.orders.qty=this.orders.qty;
//this.arr.push(this.orders);
this.flag1=true;
this.sendForm();
}

sendForm(){
JSON.stringify(this.orders);
    }
}