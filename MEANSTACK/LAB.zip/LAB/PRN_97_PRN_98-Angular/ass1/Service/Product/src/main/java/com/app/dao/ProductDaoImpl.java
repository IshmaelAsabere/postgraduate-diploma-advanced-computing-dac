package com.app.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.app.pojos.Product;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {

	@Autowired
	private SessionFactory sf;
	
	public void insertProduct(Product p) {
		
		sf.getCurrentSession().save(p);

	}

	public List<Product> listAllProducts() {
		String ss = "select p from Product p";
		return sf.getCurrentSession().createQuery(ss, Product.class).getResultList();
	}

	public void updateProduct(Product p) {
		Product pp = sf.getCurrentSession().get(Product.class, p.getPid());
		pp.setPname(p.getPname());
		pp.setPrice(p.getPrice());
		sf.getCurrentSession().update(pp);
		
	}

	public void deleteProduct(int pd) {
		Product p = sf.getCurrentSession().get(Product.class, pd);
		System.out.println("p is" + p);
		sf.getCurrentSession().remove(p);
	}

}
