package com.app.dao;

import java.util.List;

import com.app.pojos.Product;

public interface IProductDao {
	void insertProduct(Product p);
	void updateProduct(Product p);
	void deleteProduct(int pd);
	List<Product> listAllProducts();

}
