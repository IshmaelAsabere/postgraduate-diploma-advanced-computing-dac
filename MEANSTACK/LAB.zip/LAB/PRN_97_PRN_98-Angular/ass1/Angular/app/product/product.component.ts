import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService} from "../product.service";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {

  parr:Product[];
  p:Product={pid:0,pname:"",price:""};
  addUpdate="a";
  isReadOnly: boolean=false;


  constructor(private pservice:ProductService) { }

  ngOnInit() {
    this.pservice.getAllProducts().subscribe((pc)=>this.parr=pc);
  }


  submitForm(){
    if(this.addUpdate=="a"){
      this.pservice.addProduct(this.p)
      .subscribe((ad)=> this.parr=ad);
      this.isReadOnly=false;
    }
    else if(this.addUpdate=="d"){
      this.pservice.deleteProduct(this.p.pid)
      .subscribe((du) => this.parr=du);
      this.isReadOnly=false;
      this.p={pid:0,pname:"",price:""};
    }
    else if (this.addUpdate=="u"){
      this.pservice.updateProduct(this.p)
      .subscribe((pu) => this.parr=pu);
      this.p={pid:0,pname:"",price:""};
      this.isReadOnly=false;
    }
  }

  onAddClick(){
    this.addUpdate="a";
  }

  onUpdate(p1:Product,flag){
    this.addUpdate=flag;
    this.p.pid=p1.pid;
    this.p.pname=p1.pname;
    this.p.price =p1.price;
    this.isReadOnly=false;
  }
  onDelete(p1:Product,flag){
    this.addUpdate=flag;
    this.p.pid=p1.pid;
    this.p.pname=p1.pname;
    this.p.price =p1.price;
    this.isReadOnly=true;
  }
}
