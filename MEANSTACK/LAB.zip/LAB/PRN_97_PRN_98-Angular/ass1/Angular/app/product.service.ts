import { Product } from './product';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {HttpClient} from '@angular/common/http';

@Injectable()
export class ProductService{
    baseUrl="http://192.168.76.144:7070/Product/product";
    constructor(private http:HttpClient){};

    getAllProducts():Observable<Product[]>{
        return this.http.get<Product[]>(this.baseUrl);
    }

    updateProduct(p:Product):Observable<Product[]>{
        return this.http.put<Product[]>(this.baseUrl,p);
    }

    addProduct(p:Product):Observable<Product[]>{
        return this.http.post<Product[]>(this.baseUrl,p);
    }

    deleteProduct(id:number):Observable<Product[]>{
        this.baseUrl = this.baseUrl+"/"+id;
        return this.http.get<Product[]>(this.baseUrl);
    }
}