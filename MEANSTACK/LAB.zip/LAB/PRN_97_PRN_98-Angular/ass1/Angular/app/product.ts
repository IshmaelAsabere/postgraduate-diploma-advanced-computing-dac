export class Product {
    pid;
    pname;
    price;
}